#include <stdio.h>

int main()
{
    int fraction;
    printf("�п�J���� =>");
    scanf("%d", &fraction);
    
    if (fraction >= 90) {
        printf("A��!\n");
    }
    else if (fraction >= 80) {
        printf("B��!\n");
    }
     else if (fraction >= 70) {
        printf("C��!\n");
    }
     else if (fraction >= 60) {
        printf("D��!\n");
    }
    else {
        printf("F��!\n");
    }
    
    
    
	return 0;
}