#include <stdio.h>

int main()
{
    FILE  *fp;
    
    char str[50];
    
    fp = fopen("text.txt", "r");
    if (fp != NULL) {
       for (int i = 1; i <= 4; i++) {
           fgets(str, 50, fp);
           printf("%s" , str);
       }
       
       
       
       
       fclose(fp);
    } else {
       printf("�ɮ׿��~\n");
    }
    
   
    
    
	return 0;
}