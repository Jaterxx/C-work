#include <stdio.h>

int main()
{
    struct student {
        int id;
        int chi;
        int eng;
        float avg;
    };
    
    struct student std[3] = {{1, 80, 85, 0.0},
                             {2, 75, 80, 0.0},
                             {3, 90, 92, 0.0}};
    for (int i = 0; i < 3; i++) {
         std[i].avg = (float)(std[i].chi + std[i].eng) /2;
         printf("%d ���ǥ� - ���%d - �^�� %d - ����%.2f\n" , std[i].id, std[i].chi, std[i].eng, std[i].avg);   
    }
    
    
	return 0;
}