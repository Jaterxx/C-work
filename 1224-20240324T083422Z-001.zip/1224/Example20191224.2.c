#include <stdio.h>

int main()
{
    double sum, avg;
    double a[6] = {2.5, 6.9, 1.4, 3.8, 6.1, 7.2};    
    
    sum = a[0] + a[1] + a[2] + a[3] + a[4] + a[5];
    avg = sum / 6;
    
    
    printf("������ = %.2f\n" , avg);
    
    
	return 0;
}