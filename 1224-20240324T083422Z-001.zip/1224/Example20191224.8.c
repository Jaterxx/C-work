#include <stdio.h>

int main()
{
    int a[2][3] = {
                     1, 3, 2,
                     4, 5, 7
                  };
    int b[2][3] =  {
                     3, 4, 2,
                     2, 1, 1  
                   };
    int c[2][3] = {0};
    int i, j;
    
    int *pa = &a[0][0]; 
	int *pb = &b[0][0]; 
	int *pc = &c[0][0]; 
    
    for(i=0; i<2; i++)
    {
        for(j=0;j<3;j++) 
        *(pc+(i*3+j)) = *(pa+(i*3+j))+ *(pb+(i*3+j));
    }    
  
    for(i=0;i<2;i++)                                    
    { 
        for(j=0;j<3;j++) 
	    { 
        printf("c[%d,%d]=%2d",i+1,j+1,c[i][j]); 
	    } 
	    printf("\n"); 
	    } 
 
	 system("pause"); 
	} 