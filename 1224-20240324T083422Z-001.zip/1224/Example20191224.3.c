#include <stdio.h>

int main()
{
    int min_num, max_num, sum;
    int tests[5] = {5, 6, 7, 8, 9};
    min_num = tests[0];
    for (int i = 1; i < 5; i++) {
        if (tests[i] < min_num) {
        max_num = tests[i];
        }
    }
    max_num = tests[0];
    for (int i = 1; i < 5; i++) {
        if (tests[i] > min_num) {
        max_num = tests[i];
        }
    }
    sum = max_num - min_num;
    
    printf("�̤j�� = %d\n" , max_num);
    printf("�̤p�� = %d\n" , min_num);
    printf("�t�� = %d\n" , sum);
	
	return 0;
}