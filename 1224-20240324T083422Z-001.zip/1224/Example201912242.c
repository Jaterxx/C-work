#include <stdio.h>

void swap(int *x, int *y){ 
    int temp;
    temp = *x;
    *x = *y;
    *y = temp;
}
int main()
{
    int x = 10, y = 15;
    printf("X = %d\n" , x);
    printf("Y = %d\n" , y);
    
    //�Ǧ�}�I�s
    swap(&x, &y);
    
    printf("======\n");
    printf("X = %d\n" , x);
    printf("Y = %d\n" , y);
    
	return 0;
}