#include <stdio.h>

int main()
{
   int tests[7] = {1, 2, 3, 4, 5, 6, 7,};
   int str, day; 
   
   printf("�ܼƭ� = %d\n" , day);
   
   
   
   
   
   
   
   
   
	return 0;
}