#include <stdio.h>

int main()
{
    double radius, perimeter, area;
    
    printf("�п�J��b�| =>");
    scanf("%1f", &radius);
    
    perimeter = 2 * 3.1416 * radius;
    area = 3.1416 * radius * radius;
    
    printf("�b�| = %.2f\n", radius);
    printf("�P�� = %.2f\n", perimeter);
    printf("���n = %.2f\n", area);
    
	return 0;
}