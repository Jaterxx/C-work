#include <stdio.h>

int main()
{
    int a, b, sum = 0;
    printf("�п�J��Ӿ�� =>");
    scanf("%d %d", &a, &b);
    
    for (int i = a; i <= b; i++ ){
        if(i % 4 == 0 || i% 9== 0){
           sum = sum + i;
        }   
    }
    printf("%d\n" , sum);
    
    
    
	return 0;
}