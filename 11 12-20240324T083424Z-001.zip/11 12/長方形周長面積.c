#include <stdio.h>

int main()
{
    float height, width;
    printf("�п�J���P�e =>");
    scanf("%f %f ", &height, &width);
    
    printf("�� = %2f\n", height);
    printf("�e = %2f\n", width);
    printf("�P�� = %2f\n", (height+ width) * 2);
    printf("���n = %2f\n", height* width);
	return 0;
}