#include <stdio.h>

int main()
{
    int a, sum = 0;
    printf("�п�J��� =>");
    scanf("%d", &a);
    
    for (int i = 1; i <= a; i++) {
        if (i % 5 == 0){
            sum = sum + i;            
        }
    }
    printf("%d\n" , sum);
	return 0;
}